from datetime import datetime

import streamlit as st
import requests

API_URL = "http://localhost:8000"

st.title("Expense Management System")

tab1,tab2 = st.tabs(["Add/Update","Analytics"])

with tab1:
    selected_date = st.date_input("Enter Date:", datetime(2026,3,19), label_visibility="collapsed")
    response = requests.get(f"{API_URL}/expenses/{selected_date}")
    if response.status_code == 200:
        existing_expenses = response.json()
        st.write(existing_expenses)
    else:
        st.error("Failed to retrieve expenses")
        existing_expenses = []

    with st.form(key = "expense_form"):
        for i in range(5):
            col1, col2, col3 = st.columns(3)
            with col1:
                st.number_input(label=
                                "Amount", min_value=0.0,step=1.0,value=0,key=f"amount")



